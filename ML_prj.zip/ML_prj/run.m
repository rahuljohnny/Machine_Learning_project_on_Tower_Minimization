%==========================Feature Normalization
clear ; close all; clc
fprintf('Loading data ...\n');

data = load('inputTrainingSet.txt');
X = data(:, 1:2);%1 to 2
y = data(:,3 );
m = length(y); 

fprintf('First 10 examples: \n');
fprintf(' x = [%.0f %.0f], y = %.0f \n', [X(1:10,:) y(1:10,:)]');

fprintf('Program paused. Press enter to continue.\n');
pause;

fprintf('Normalizing Features ...\n');

[X mu sigma] = featureNormalize(X);%========A func which'll take X,mu,sigma as parameter

%fprintf('featureNormalize= %f \n',featureNormalize(X));

X = [ones( m, 1) X];%========Bias added to x0 till m

%% ================ Gradient Descent

fprintf('=============================================\n\ngradient descent  ......\n');

alpha = 0.01;
num_iters =400; %total no. of dataset

theta = zeros(3, 1);%theta=1to3=0
[theta, J_history] = gradientDescentMulti(X, y, theta, alpha, num_iters);

%==================convergence graph
figure;
plot(1:numel(J_history), J_history, '-b', 'LineWidth', 2);
xlabel('Iterations(I)');
ylabel('Cost(J)');

%==================gradient descent's result
fprintf('Theta computed from gradient descent: \n');
fprintf('theta : %.0f \n', theta);
fprintf('\n');

data2 = csvread('input.txt');
X1 = data2(:, 1);
X2 = data2(:, 2);

%for specific users and area 
normalizedusers = (X1 - mu) / sigma;
normalizedarea = (X2 - mu) / sigma;


normalizedInput = [1, normalizedarea, normalizedusers];%#the_bias_1
tGD = 2*normalizedInput * theta; %I_changed_it :)

fprintf(['==using Gradient Discent===\nArea: %.2f sq-km\nUsers: %.0f\nPredicted no. of towers:%.0f\n'],X2,X1,tGD);

fprintf('\nProgram paused. Press enter to continue.\n');
 
pause;
 

% ==================================== Normal Equations

fprintf('\n\nSolving with normal equations.......\n');

data = csvread('inputTrainingSet.txt');
X = data(:, 1:2);
y = data(:, 3);
m = length(y);

% Adding bias
X = [ones(m, 1) X];%setting one to all X0 till m

theta = normalEquation(X, y); 

fprintf('Theta computed from the normal equations: \n');
fprintf(' %f \n', theta); 
fprintf('\n');

% Estimate towers 
 towers = [1, X1, X2] * theta; %take as input
 fprintf(['===using normal equations===\nUsers:%.0f\nArea:%.2f sq-km\n\nPredicted no. of towers:%.0f\n'],X1,X2, towers);